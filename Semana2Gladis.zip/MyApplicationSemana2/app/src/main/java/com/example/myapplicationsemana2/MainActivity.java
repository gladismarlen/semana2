package com.example.myapplicationsemana2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private EditText Nombre, Telefono, Email, Contacto;
    private Button miBoton;
    private CalendarView Fecha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Nombre = (EditText) findViewById(R.id.editText);
        Telefono = (EditText) findViewById(R.id.editText2);
        Fecha = (CalendarView) findViewById(R.id.calendarView);
        Email = (EditText) findViewById(R.id.editText3);
        Contacto = (EditText) findViewById(R.id.editText4);
        miBoton = (Button) findViewById(R.id.button);

        miBoton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, Main2Activity.class);
                i.putExtra("Nombre", Nombre.getText() + "");

                i.putExtra("Telefono", Telefono.getText() + "");
                i.putExtra("Email", Email.getText() + "");
                i.putExtra("Contacto", Contacto.getText() + "");

                startActivity(i);

            }
        });
    }
}
